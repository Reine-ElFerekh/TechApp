package com.lau.techassignment4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;
public class MainActivity extends AppCompatActivity {

    ArrayList<String> title;
    ArrayList<Integer> id;
    ArrayList<String> url;
    ArrayList<String> title2;
    ArrayList<String> id2;
    ArrayList<String> url2;
    SQLiteDatabase sqdb;
    ListView listView;
    ArrayAdapter arrAdapter;
    public class DownloadTask extends AsyncTask<String, Void, String> {
        protected String doInBackground(String... urls){
            String rslt = "";
            URL url;
            HttpURLConnection connection;
            try{
                url = new URL(urls[0]);
                connection = (HttpURLConnection) url.openConnection();
                InputStream in = connection.getInputStream();
                InputStreamReader inreader = new InputStreamReader(in);
                int data = inreader.read();
                while(data != -1){
                    char curr = (char) data;
                    rslt += curr;
                    data = inreader.read();
                }
                return rslt;
            }catch(Exception e) {
                e.printStackTrace();
                return null;
            }
        }
        protected void onPostExecute(String str){
            super.onPostExecute(str);
            title = new ArrayList<>();
            id = new ArrayList<>();
            url = new ArrayList<>();
            try{
                JSONArray array1 = new JSONArray(str);
                for(int i = 14; i < 34 ; i++){
                    int x = array1.getInt(i);
                    MainActivity.this.id.add(x);
                    DownloadTasknbr2 task2 = new DownloadTasknbr2();
                    task2.execute("https://hacker-news.firebaseio.com/v0/item/" + array1.getInt(i) + ".json?print=pretty");
                }
            } catch(Exception e){
                e.printStackTrace();
            }
        }
    }
    public void GoToActivity2(int i)
    {
        Intent intent = new Intent(this, WebActivity.class);
        intent.putExtra("url", url2.get(i));
        startActivity(intent);
    }
    public void ListInfo(){
        ArrayList<String> titleArray = new ArrayList<>();
        for (int i = 0; i < 20; i++){
            titleArray.add(title.get(i));
        }
        arrAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, titleArray);
        listView.setAdapter(arrAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l)
            {
                GoToActivity2(i);
            }
        });
    }
    public class DownloadTasknbr2 extends AsyncTask<String, Void, String> {
        protected String doInBackground(String... urls){
            String rslt = "";
            URL url;
            HttpURLConnection connection;
            try{
                url = new URL(urls[0]);
                connection = (HttpURLConnection) url.openConnection();
                InputStream in = connection.getInputStream();
                InputStreamReader inreader = new InputStreamReader(in);
                int data = inreader.read();
                while (data != -1) {
                    char curr = (char) data;
                    rslt = rslt + curr;
                    data = inreader.read();
                }
                return rslt;
            }catch(Exception e) {
                e.printStackTrace();
                return null;
            }
        }
        protected void onPostExecute(String str){
            super.onPostExecute(str);
            try{
                JSONObject json = new JSONObject(str);
                String title = json.getString("title");
                MainActivity.this.title.add(title);
                String Url = json.getString("url");
                url.add(Url);
                ListInfo();
                InDatabase();

            }catch(Exception e){
                e.printStackTrace();
            }
        }
    }
    public void InDatabase()
    {
        sqdb = this.openOrCreateDatabase("My_db", MODE_PRIVATE, null);
        sqdb.execSQL("CREATE TABLE IF NOT EXISTS articles(url VARCHAR, title VARCHAR, id VARCHAR)");
        for(int i = 0; i < 20; i++)
        {
            String arcTitle = this.title.get(i);
            String arcUrl = this.url.get(i);
            String arcID = String.valueOf(this.id.get(i));
            sqdb.execSQL("INSERT INTO articles(url, title, id) VALUES(\""+arcUrl+"\", \""+arcTitle+"\", \""+arcID+"\")");
        }

    }
    public void content()
    {
        sqdb = this.openOrCreateDatabase("My_db", MODE_PRIVATE, null);
        Cursor cursor = sqdb.rawQuery("SELECT * FROM articles", null);
        int URL;
        int title;
        URL = cursor.getColumnIndex("url");
        title = cursor.getColumnIndex("title");
        cursor.moveToFirst();
        for(int i=0; i<cursor.getCount();i++)
        {
            title2.add(cursor.getString(title));
            url2.add(cursor.getString(URL));
            id2.add(cursor.getString(URL));
            cursor.moveToNext();
        }
        ListInfo();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView) findViewById(R.id.listView);
        title = new ArrayList<>();
        id = new ArrayList<Integer>();
        url = new ArrayList<>();
        //content();
        DownloadTask task = new DownloadTask();
        task.execute("https://hacker-news.firebaseio.com/v0/topstories.json");
    }
}